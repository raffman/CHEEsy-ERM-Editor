
                ___-´\
          __ --  (_)  \
   ___ --    o     ____\
  |   _`----------´_    )
  |  (_)  _    O  (_)   |
  | o    (_)    __   o  )
  `------------´  `----´

********************************************************************************
********************  CHEEsy - Chen ERM Editor super yummy  ********************
********************************************************************************

1. DESCRIPTION
2. INSTALLATION
3. USAGE
4. LICENSE
5. CONTACT

*******************************  1. DESCRIPTION  *******************************
CHEEsy (Chen ERM Editor super yummy) is a Fachhochschule-Technikum-Wien IT project.
This tool is meant for drawing ERM diagrams.

*******************************  2. INSTALLATION  ******************************
Either download the source code and compile or download the zip file with the executable program.

*******************************  3. USAGE  *************************************
Draw diagrams and stuff
For further information view manual.

*******************************  4. LICENSE  ***********************************
CHEEsy is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

CHEEsy is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with CHEEsy. If not, see <http://www.gnu.org/licenses/>.

*******************************  5. CONTACT  ***********************************
Raffael Lorup
Ary Obenholzer
Robert Pinnisch
William Wang